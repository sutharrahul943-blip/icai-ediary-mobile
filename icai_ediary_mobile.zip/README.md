# ICAI SSP E-Diary Auto-Filler — Mobile (Android)

Final, simplified version. App flow:

1. Enter your SSP username/password once, tap **Save Login**.
2. Date is auto-filled to today (you can edit it). Pick **Duration** and
   **Task** from dropdowns. Optionally type an **Other Task**.
3. Tap **Submit (Login & Fill E-Diary)**.
4. The app opens the real ICAI site and auto-fills your saved
   username/password. **You solve the CAPTCHA and tap Sign-in yourself**
   — this is the one step no automation can skip, since CAPTCHAs exist
   specifically to require a human.
5. Once logged in, it opens the E-Diary form and auto-fills Date,
   Duration, and Task.
6. ICAI generates the Sub-Task checkboxes dynamically depending on which
   Task you picked, so there's no way to know those options in advance.
   The app pulls the real list straight from the live page at that moment
   and shows it to you as a dropdown — pick one and tap Confirm.
7. It checks that sub-task box and fills Other Task, then **stops**. It
   never taps Save — you get 2 minutes to review and tap Save yourself.

---

## Important — read this first

I cannot compile this into an installable `.apk` myself: I don't have
internet access or the Android build toolchain in my environment. What I
*can* give you is complete, working source code plus a free automated
cloud build (GitHub Actions) that turns it into an APK for you — done
entirely from your phone's browser, no PC involved. That one-time setup
is below.

---

## Step 1 — Create a free GitHub account

github.com in your phone's browser → sign up (skip if you have one).

## Step 2 — Create a new repository

**+** icon → **New repository** → name it e.g. `icai-ediary-mobile` →
**Create repository**.

## Step 3 — Add the project files

1. Download the ZIP this app came with, and extract it using your phone's
   file manager (tap it → **Extract**).
2. In your repo: **Add file → Upload files** → select every extracted
   file **except** the `.github` folder → **Commit changes**.

## Step 4 — Add the workflow file (the one hidden-folder file)

1. **Add file → Create new file**.
2. Filename: `.github/workflows/build.yml` (typing the slashes makes
   GitHub create the folders automatically).
3. Paste:

```yaml
name: Build Android APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Check out the repo
        uses: actions/checkout@v4

      - name: Build APK with Buildozer
        uses: ArtemSBulgakov/buildozer-action@v1
        id: buildozer
        with:
          command: buildozer android debug
          buildozer_version: stable

      - name: Upload the built APK
        uses: actions/upload-artifact@v4
        with:
          name: icai-ediary-apk
          path: ${{ steps.buildozer.outputs.filename }}
```

4. **Commit changes.**

## Step 5 — Wait for the build

**Actions** tab → the run starts automatically. First build takes
15–25 minutes (later ones are faster). If it doesn't start, use the
**Run workflow** button.

## Step 6 — Download and install

Green checkmark → open the run → **Artifacts** → download
`icai-ediary-apk` (it's a zip — extract it to get the real `.apk`) → tap
it → allow "install unknown apps" if prompted → install → open.

## If a build fails

Open the failed run, expand the red step, and paste the error to me —
I'll tell you exactly what to fix in which file, and you can edit it
right in GitHub's web page editor (tap the file → pencil icon).

## Files in this project

| File | Purpose |
|---|---|
| `main.py` | The app itself — screens, buttons, the automation flow above |
| `secure_storage.py` | Encrypts your saved password (no plaintext) |
| `webview_bridge.py` | Native Android WebView + JS injection (does what Playwright can't do on mobile) |
| `buildozer.spec` | Tells the build tool how to package the APK |
| `.github/workflows/build.yml` | Tells GitHub's free cloud servers how to build it |
